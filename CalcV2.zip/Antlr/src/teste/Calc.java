package teste;
import org.antlr.v4.runtime.misc.NotNull;

public class Calc extends TesteBaseVisitor {
	          
	    @Override
	    public Double visitPrintExpr(TesteParser.PrintExprContext ctx) {
	        Double value = (Double) visit(ctx.expr());
	        System.out.println(value);
	        return 0.;
	    }
	     
	    @Override
	    public Double visitInt(TesteParser.IntContext ctx) {
	        return Double.valueOf(ctx.INT().getText());
	    }
	     	     
	    @Override
	    public Double visitMulDiv(TesteParser.MulDivContext ctx) {
	        double left = (Double) visit(ctx.expr(0));
	        double right = (Double) visit(ctx.expr(1));
	        if ( ctx.op.getType() == TesteParser.MUL ) return left * right;
	        else return left / right;
	    }
	 	     
	    public Double visitAddSub(@NotNull TesteParser.AddSubContext ctx) {
	    	    double left = (Double) visit(ctx.expr(0));
		        double right = (Double) visit(ctx.expr(1));
		        if ( ctx.op.getType() == TesteParser.ADD ) return left + right;
		        else return left - right;
	    }
	    @Override
	    public Double visitParens(TesteParser.ParensContext ctx) {
	        return (Double) visit(ctx.expr());
	    }
}
