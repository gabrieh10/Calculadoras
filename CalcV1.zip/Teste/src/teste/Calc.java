package teste;
import java.util.HashMap;
import java.util.Map;

import org.antlr.v4.runtime.misc.NotNull;

public class Calc extends Teste2BaseVisitor {         
	    @Override
	    public Double visitPrintExpr(Teste2Parser.PrintExprContext ctx) {
	        Double value = (Double) visit(ctx.expr());
	        System.out.println(value);
	        return value;
	    }
	     
	    @Override
	    public Double visitInt(Teste2Parser.IntContext ctx) {
	        return Double.valueOf(ctx.INT().getText());
	    }     
	    @Override
	    public Double visitOp(@NotNull Teste2Parser.OpContext ctx) {
	        double left = (Double) visit(ctx.expr(0));
	        double right = (Double) visit(ctx.expr(1));
	        if ( ctx.op.getType() == Teste2Parser.MUL ) return left * right;
	        else if(ctx.op.getType() == Teste2Parser.DIV) return left/right; 
	        else if (ctx.op.getType() == Teste2Parser.ADD) return left + right;
	        else return left-right;
	    }
	 	     
	    @Override
	    public Double visitParens(Teste2Parser.ParensContext ctx) {
	        return (Double) visit(ctx.expr());
	    }
}
