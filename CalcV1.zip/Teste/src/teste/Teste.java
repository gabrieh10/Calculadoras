package teste;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.FileInputStream;
import java.io.InputStream;
 
public class Teste {
    public static void main(String[] args) throws Exception {
        InputStream file = new FileInputStream("File.txt"); 
        ANTLRInputStream input = new ANTLRInputStream(file); // S/ precedencia nos op e nao reconhece blank space
        Teste2Lexer lexer = new Teste2Lexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        Teste2Parser parser = new Teste2Parser(tokens);
        ParseTree tree = parser.prog();
        Calc eval = new Calc();
        eval.visit(tree);
    }
}